INSTAGRAVED 7.0 PRETO

Arquivo principal: index.html
Tema: preto
Inclui as funções existentes na versão fornecida, incluindo perfil, stories/destaques, música/notas, notificações, chat, compartilhamento de perfil, painel do dono, usuários online, contas banidas e fluxo de Central de Contas/Senha e segurança/Alterar senha.

Para colocar como site, publique esta pasta em um serviço de hospedagem estática (por exemplo, GitHub Pages).
Para Google Play, este HTML/PWA ainda precisa ser empacotado como aplicativo Android e gerar um AAB/APK.
